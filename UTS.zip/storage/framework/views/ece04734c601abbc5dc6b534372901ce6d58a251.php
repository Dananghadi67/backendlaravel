<?php $__env->startSection('title', 'Edit Data'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <div class="card card-info">
            <div class="card-header">
                <h3 class="card-title"><?php echo e(Auth::user()->name); ?></h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form class="form-horizontal" method="POST" action="/dashboard09/update-data09"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-body">
                    <div class="form-group row">
                        <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" id="alamat" placeholder="Alamat"
                                name="alamat"><?php echo e($item->alamat); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tempat" class="col-sm-2 col-form-label">Tempat Lahir</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="tempat" placeholder="Tempat Lahir" name="tempat"
                                value=<?php echo e($item->tempat_lahir); ?>>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tanggal" class="col-sm-2 col-form-label">Tanggal Lahir</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" id="tanggal" placeholder="Tanggal Lahir"
                                name="tanggal" value=<?php echo e($item->tanggal_lahir); ?>>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="agama" class="col-sm-2 col-form-label">Agama</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="agama" id="agama">
                                <?php $__currentLoopData = $agama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value=<?php echo e($agama->id); ?> <?php if($agama->id==$item->id_agama): ?> selected
                                    <?php endif; ?>><?php echo e($agama->nama_agama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label">Foto KTP</label>
                        <div class="col-sm-10">
                            <div class="row mb-2">
                                <img src="/ktp/<?php echo e($item->foto_ktp); ?>" width="100%" alt="">
                            </div>
                            <div class="row">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="ktp" accept="image/jpeg"
                                        name="ktp">
                                    <label class="custom-file-label" for="ktp">Choose File</label>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                    <button type="submit" class="btn btn-info">Update</button>
                    <button onclick="history.back()" class="btn btn-default float-right">Cancel</button>
                </div>
                <!-- /.card-footer -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UNS\MATKUL\SEMESTER 3\BackEnd\laravel\laravel\uts-backend\resources\views/user/edit.blade.php ENDPATH**/ ?>