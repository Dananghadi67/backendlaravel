
<?php $__env->startSection('title', 'Detail User'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <!-- Profile Image -->
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card card-primary card-outline">
            <div class="card-body box-profile">
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="text-center">
                    <img class="profile-user-img img-fluid img-circle mb-2" src="/profil/<?php echo e($user->foto); ?>"
                        alt="User profile picture">
                </div>
                <h3 class="profile-username text-center"><?php echo e($user->name); ?></h3>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <ul class="list-group list-group-unbordered mb-3">
                    <li class="list-group-item">
                        <b>Alamat</b> <a class="float-right"><?php echo e($item->alamat); ?></a>
                    </li>
                    <li class="list-group-item">
                        <b>Tempat Lahir</b> <a class="float-right"><?php echo e($item->tempat_lahir); ?></a>
                    </li>
                    <li class="list-group-item">
                        <b>Tanggal Lahir</b> <a class="float-right"><?php echo e($item->tanggal_lahir); ?></a>
                    </li>
                    <li class="list-group-item">
                        <b>Umur</b> <a class="float-right"><?php echo e($item->umur); ?></a>
                    </li>
                    <li class="list-group-item">
                        <b>Foto KTP</b> <a class="float-right"><img width="100%" src="/ktp/<?php echo e($item->foto_ktp); ?>"
                                alt=""></a>
                    </li>
                </ul>
            </div>
            <!-- /.card-body -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- /.card -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BackEnd\UTS\resources\views/admin/detail_user.blade.php ENDPATH**/ ?>