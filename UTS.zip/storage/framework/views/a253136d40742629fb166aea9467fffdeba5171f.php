<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col 12">
        <?php if(Auth::user()->is_aktif == '0'): ?>
        <div class="alert alert-danger" role="alert">
            <h4 class="alert-heading">Pemberitahuan!</h4>
            <p>Mohon maaf, akun anda belum di aktivasi oleh admin.</p>
            <hr>
            <p class="mb-0">Mohon menunggu atau silahkan hubungi admin jika penting.</p>
        </div>
        <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item->alamat==null||$item->tempat_lahir==null||$item->tanggal_lahir==null): ?>
        <div class="alert alert-success" role="alert">
            <h4 class="alert-heading">Pemberitahuan!</h4>
            <p>Selamat akun anda telah di aktivasi oleh admin.</p>
            <hr>
            <p class="mb-0">Untuk langkah selanjutnya silahkan update data diri anda pada link berikut, <a
                    href="/dashboard30/edit-data30"><b>Update Data</b></a>.</p>
        </div>
        <?php else: ?>
        <div class="col-md-6">

            <!-- Profile Image -->
            <div class="card card-primary card-outline">
                <div class="card-body box-profile">
                    <div class="text-center">
                        <img class="profile-user-img img-fluid img-circle mb-2" src="profil/<?php echo e(Auth::user()->foto); ?>"
                            alt="User profile picture">
                        <form action="/dashboard30/update-foto-profil30" method="POST" class="form-horizontal"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="profil" accept="image/jpeg"
                                    name="profil">
                                <label class="custom-file-label" for="profil">Pilih Foto</label>
                            </div>
                            <div class="mt-2">
                                <button type="submit" class="btn btn-info">Ganti Foto</button>
                            </div>
                        </form>
                    </div>

                    <h3 class="profile-username text-center"><?php echo e(Auth::user()->name); ?></h3>

                    <ul class="list-group list-group-unbordered mb-3">
                        <li class="list-group-item">
                            <b>Alamat</b> <a class="float-right"><?php echo e($item->alamat); ?></a>
                        </li>
                        <li class="list-group-item">
                            <b>Tempat Lahir</b> <a class="float-right"><?php echo e($item->tempat_lahir); ?></a>
                        </li>
                        <li class="list-group-item">
                            <b>Tanggal Lahir</b> <a class="float-right"><?php echo e($item->tanggal_lahir); ?></a>
                        </li>
                        <li class="list-group-item">
                            <b>Umur</b> <a class="float-right"><?php echo e($item->umur); ?></a>
                        </li>
                        <li class="list-group-item">
                            <b>Foto KTP</b> <a class="float-right"><img width="100%" src="ktp/<?php echo e($item->foto_ktp); ?>"
                                    alt=""></a>
                        </li>
                        <li class="list-group-item">
                            <a href="/dashboard30/ganti-password30" class="btn btn-danger float-left"><i
                                    class="fa fa-tools"></i> Ganti password</a>
                            <a href="/dashboard30/edit-data30" class="btn btn-info float-right"><i
                                    class="fa fa-edit"></i> Edit data</a>
                        </li>
                    </ul>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BackEnd\UTS\resources\views/user/dashboard.blade.php ENDPATH**/ ?>