<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Admin Profile
                </h3>
            </div>
            <div class="card-body row">
                <div class="col-md-2">
                    <img width="100%" src="/profil/<?php echo e(Auth::user()->foto); ?>" alt="">
                </div>
                <div class="col-md-4">
                    <form action="/admin30/dashboard30/update-foto-profil30" method="POST" class="form-horizontal"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="profil" accept="image/jpeg" name="profil">
                            <label class="custom-file-label" for="profil">Pilih Foto</label>
                        </div>
                        <div class="mt-2">
                            <button type="submit" class="btn btn-info">Ganti Foto</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar User</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="table" class="table table-bordered table-striped">
                    <thead>
                        <tr class="text-center">
                            <th>Foto Profil</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Register Datetime</th>
                            <th>Status Aktif</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><img style="width: 10rem" src="/profil/<?php echo e($item->foto); ?>" alt=""></td>
                            <td><?php echo e($item->name); ?> </td>
                            <td><?php echo e($item->email); ?></td>
                            <td><?php echo e($item->created_at); ?></td>
                            <td class="text-center">
                                <?php if($item->is_aktif=='1'): ?>
                                <span class="badge bg-success">Aktif</span>
                                <?php else: ?>
                                <span class="badge bg-warning">Belum Aktif</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <a href=<?php echo e("/admin30/dashboard30/detail30/".Crypt::encrypt($item->id)); ?> class="btn
                                    btn-primary mx-1"><i class="fa fa-info-circle"></i> Detail</a>
                                <?php if($item->is_aktif=='0'): ?>
                                <a href=<?php echo e("/admin30/approve30/".Crypt::encrypt($item->id)); ?> class="btn btn-success
                                    mx-1"><i class="fa fa-user-check"></i> Approve
                                    User</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BackEnd\UTS\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>